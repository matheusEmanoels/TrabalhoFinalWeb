package com.utfpr.edu.br.trabalhoweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabalhoWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
